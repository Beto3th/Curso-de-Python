
def potencia(base, exponente):
    print("EL resultado del exponente es: ", base**exponente)

def redondear(numero):
    print("El redondeo da: ", round(numero))