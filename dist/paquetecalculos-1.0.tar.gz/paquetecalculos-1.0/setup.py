from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Roberto",
    author_email="robplayer15@gmmial.com",
    packages=["Calculos", "Calculos.Redondeo_Potencia"]

    )